package com.aitech.library.book;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class BookController {
	
	private static final String UPLOADDIR =
			System.getProperty("user.dir") + "/upload/book_images/";
	
	@Autowired
	private BookDao bookDao;
	
	public BookController(BookDao bookDao) {
		this.bookDao = bookDao;
	}

	@RequestMapping("/booklist")
	public String booklist(Model model) {
		List<BookVo> books = bookDao.getAllBook();
		model.addAttribute("books", books);
		return "book/book_list";
	}
	
	@RequestMapping("/registerbook")
	public String registerbook() {
		return "admin/register_book";
	}
	
	private String saveBookImg(MultipartFile file) throws Exception {
		File dir = new File(UPLOADDIR);
		if(!dir.exists())
			dir.mkdir();
		
		String fileName = new SimpleDateFormat("yyyyMMdd_HHmmss_").format(new Date())
				+ file.getOriginalFilename();
		file.transferTo(new File(UPLOADDIR + fileName));
		
		return fileName;
	}
	
	private void deleteBookImg(String b_img) {
		if(b_img != null && !b_img.isEmpty()) {
			new File(UPLOADDIR + b_img).delete();
		}
	}
	
	@RequestMapping("/registerbookconfirm")
	public String registerbookconfirm(BookVo bookVo, 
			@RequestParam("b_img_file") MultipartFile file) throws Exception {
		if(!file.isEmpty()) {
			bookVo.setB_img(saveBookImg(file));
		}
		bookDao.insertBook(bookVo);
		return "redirect:managementbook";
	}
	
	@RequestMapping("/managementbook")
	public String managementbook(Model model) {
		List<BookVo> books = bookDao.getAllBook();
		model.addAttribute("books", books);
		return "admin/management_book";
	}
	
	@RequestMapping("/detailbook")
	public String detailbook(@RequestParam("b_no") int b_no, Model model) {
		model.addAttribute("book", bookDao.getDetailBook(b_no));
		return "book/book_detail";
	}
	
	@RequestMapping("/modifybook")
	public String modifybook(@RequestParam("b_no") int b_no, Model model) {
		model.addAttribute("book", bookDao.getDetailBook(b_no));
		return "admin/modify_book";
	}
	
	@RequestMapping("/modifybookconfirm")
	public String modifybookconfirm(BookVo bookVo,
			@RequestParam("b_img_file") MultipartFile file) throws Exception {
		BookVo oldBook = bookDao.getDetailBook(bookVo.getB_no());
		if(!file.isEmpty()) {
			bookVo.setB_img(saveBookImg(file));
			deleteBookImg(oldBook.getB_img());
		} else {
			bookVo.setB_img(oldBook.getB_img());
		}
		bookDao.updateBook(bookVo);
		return "redirect:managementbook";
	}
	
	@RequestMapping("/deletebook")
	public String deletebook(@RequestParam("b_no") int b_no) {
		BookVo oldBook = bookDao.getDetailBook(b_no);
		bookDao.deleteBook(b_no);
		deleteBookImg(oldBook.getB_img());
		return "redirect:managementbook";
	}
}
