package com.aitech.library.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDao {
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public MemberDao(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public void insertMember(MemberVo memberVo) {
		String sql = "INSERT INTO member(m_id, m_pw, m_name, m_gender, "
				+ "m_mail, m_phone, m_role, m_reg_date, m_mod_date) "
				+ "VALUES(?, ?, ?, ?, ?, ?, 'USER', now(), now())";
		jdbcTemplate.update(sql, memberVo.getM_id(), memberVo.getM_pw(), memberVo.getM_name(),
				memberVo.getM_gender(), memberVo.getM_mail(), memberVo.getM_phone());
	}
}
