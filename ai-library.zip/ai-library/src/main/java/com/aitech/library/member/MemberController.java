package com.aitech.library.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MemberController {
	
	@Autowired
	private MemberDao memberDao;
	
	@RequestMapping("/registermember")
	public String registermember() {
		return "user/register_member";
	}
	@RequestMapping("/registermemberconfirm")
	public String registermemberconfirm(MemberVo memberVo) {
		memberDao.insertMember(memberVo);
		return "user/register_member";
	}
}
