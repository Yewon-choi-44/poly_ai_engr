<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ include file="../include/header.jsp"%>
	<input type="text" name="searchTxt" class="form-control" placeholder="메뉴명을 입력하세요">
	<button class="btn btn-dark flex-shrink-0">검색</button>

	<h3 class="mb-3">메뉴</h3>
	<div class="row">
			<div class="col-md-3 mb-4">
				<div class="card h-100">
					<div class="d-flex align-items-center justify-content-center bg-secondary-subtle text-secondary" style="height: 140px;">
						<img src="" class="card-img-top" style="height: 140px; object-fit: cover;" alt="메뉴사진"> 
					</div>
					<div class="card-body text-center">
						<div class="mb-2">
							<span class="badge bg-success">판매중</span>
							<span class="badge bg-secondary">품절</span>
						</div>
						<h5 class="card-title">메뉴</h5>
						<p class="fw-bold mb-3">가격</p>
								<div class="d-grid"><a href="#" class="btn btn-warning fw-bold">주문하기</a></div>
								<div class="d-grid"><button class="btn btn-outline-secondary" disabled>품절</button></div>
					</div>
				</div>
			</div>
	</div>
<%@ include file="../include/footer.jsp"%>
