<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>캠퍼스 카페</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
	<nav class="navbar navbar-expand bg-dark" data-bs-theme="dark">
		<div class="container">
			<a class="navbar-brand fw-bold" href="#">☕ 캠퍼스 카페</a>
			<div class="navbar-nav">
				<a class="nav-link" href="#">메뉴</a>
				<a class="nav-link" href="#">로그인</a>
				<a class="nav-link" href="#">내주문</a>
				<a class="nav-link" href="#">로그아웃</a>
			</div>
		</div>
	</nav>
	<div class="container mt-4">
