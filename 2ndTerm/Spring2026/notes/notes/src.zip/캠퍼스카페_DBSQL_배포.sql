CREATE DATABASE IF NOT EXISTS aitech_cafe26 DEFAULT CHARACTER SET utf8mb4;
USE aitech_cafe26;

CREATE TABLE member (
    m_no       INT AUTO_INCREMENT PRIMARY KEY,
    m_id       VARCHAR(50)  NOT NULL UNIQUE,
    m_pw       VARCHAR(100) NOT NULL,
    m_name     VARCHAR(50)  NOT NULL,
    m_gender   CHAR(1)      NOT NULL,
    m_mail     VARCHAR(100) NOT NULL,
    m_phone    VARCHAR(20)  NOT NULL,
    m_role     VARCHAR(10)  NOT NULL DEFAULT 'USER',
    m_reg_date DATETIME     NOT NULL,
    m_mod_date DATETIME     NOT NULL
);

INSERT INTO member (m_id, m_pw, m_name, m_gender, m_mail, m_phone, m_reg_date, m_mod_date) VALUES
('guest01', '1234', '김하나', 'M', 'guest01@test.com', '010-1111-2222', NOW(), NOW()),
('guest02', '1234', '박두리', 'F', 'guest02@test.com', '010-3333-4444', NOW(), NOW());

CREATE TABLE menu (
    mn_no       INT AUTO_INCREMENT PRIMARY KEY,
    mn_name     VARCHAR(100) NOT NULL,
    mn_price    INT NOT NULL,
    mn_desc     TEXT,
    mn_img      VARCHAR(200),              
    mn_sale     INT NOT NULL DEFAULT 1,    -- 1 판매중 / 0 품절
    mn_reg_date DATETIME NOT NULL,
    mn_mod_date DATETIME NOT NULL
);

CREATE TABLE orders (
    o_no       INT AUTO_INCREMENT PRIMARY KEY,
    mn_no      INT NOT NULL,
    m_no       INT NOT NULL,
    o_qty      INT NOT NULL,
    o_req      VARCHAR(200) NULL,
    o_status   INT NOT NULL DEFAULT 1,     -- 1 주문됨 / 2 준비중 / 3 완료 / 0 취소
    o_reg_date DATETIME NOT NULL,
    o_mod_date DATETIME NOT NULL,
    FOREIGN KEY (mn_no) REFERENCES menu(mn_no),
    FOREIGN KEY (m_no)  REFERENCES member(m_no)
);

INSERT INTO menu (mn_name, mn_price, mn_desc, mn_img, mn_sale, mn_reg_date, mn_mod_date) VALUES
('아메리카노',   2500, '깔끔한 기본 커피',        'americano.png',           1, NOW(), NOW()),
('카페라떼',     3500, '부드러운 우유 거품',      'latte.png',               1, NOW(), NOW()),
('바닐라라떼',   4000, '달콤한 바닐라 시럽',      'vanilla_latte.png',       1, NOW(), NOW()),
('딸기스무디',   4500, '생딸기 갈아 넣음',        'strawberry_smoothie.png', 1, NOW(), NOW()),
('치즈케이크',   5500, '진한 수제 치즈케이크',    'cheesecake.png',          0, NOW(), NOW());  -- 품절 검수용
