def select_sort(in_data):
    n = len(in_data)
    for i in range(n-1):
        for j in range(i+1, n):
            if (in_data[j] < in_data[i]).any():
                in_data[i], in_data[j] = in_data[j], in_data[i]
        print(f"{i+1}회전 결과 \n: {in_data}")
###################################################################
def median_filter(in_img):
    for k in range(len(in_img)):
        select_sort(in_img[0:3, 0:3])

###################################################################
import cv2
noise_img = cv2.imread("C:/Users/AI-00/Desktop/salt-pepper-noise.jpg")
#noise_img = cv2.imread('C:/Users/AI-00/Desktop/하이테크_/AI데이터전처리실습/0511/saltandpepperlena-300x300.jpg')
#print(type(noise_img), noise_img.shape())
input_img = cv2.cvtColor(noise_img, cv2.COLOR_BGR2GRAY)
filter_img = median_filter(input_img)
print(type(input_img.shape))
cv2.imshow("noise_img", noise_img)
cv2.waitKey()