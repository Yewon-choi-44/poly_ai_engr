# Wiki Index

## Categories

### Wiki
- [ML](wiki/ml/index.md) - Machine Learning notes and concept documents
  - [MML Study](wiki/ml/mml/index.md) - Mathematics for Machine Learning book study
- [Infra](wiki/infra/index.md) - Infrastructure, networks, and DevOps notes
- [Errors](wiki/errors/index.md) - Troubleshooting and error logs
- [CS](wiki/cs/index.md) - Computer Science core concepts
  - [Python Study](wiki/cs/python/index.md) - Core Python programming study notes
- [Algorithms](wiki/algorithms/index.md) - Data Structure & Algorithm study dashboard
- [Projects](wiki/projects/index.md) - Side projects and active project notes
- [Papers](wiki/papers/index.md) - Academic papers summary

### References
- [LLM Wiki Guide](references/llm-wiki.md) - Guide for running LLM Wiki
- [OKF Specification](references/okf-spec.md) - Open Knowledge Format Spec
