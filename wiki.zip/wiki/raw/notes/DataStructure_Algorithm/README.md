# Data Structure & Algorithm Notes

이 디렉토리는 자료구조 및 알고리즘 학습을 위한 원본 자료(raw notes, 강의 자료, 코드 조각 등)를 보관하는 공간입니다.
자료가 추가되면 AGENTS.md의 운영 규칙에 따라 `wiki/algorithms/` 또는 관련 위키 문서로 정리 및 교차 링크됩니다.
