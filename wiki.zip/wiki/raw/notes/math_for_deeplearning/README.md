# Math for Deep Learning

이 폴더는 '딥러닝을 위한 수학' 과목의 수업 필기, 강의 자료 원본, 과제 등 정제되지 않은 데이터들을 보관하는 공간입니다.

- 이 폴더 내의 자료는 수정하지 않고 원본 그대로 보존합니다.
- 학습을 마친 핵심 수학 개념들은 [wiki/ml/](file:///D:/wiki/wiki/ml) 또는 [wiki/cs/](file:///D:/wiki/wiki/cs) 디렉터리에 개념(Concept) 문서로 요약 및 정제하여 기록합니다.
