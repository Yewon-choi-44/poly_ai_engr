package com.aitech.library.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpSession;

@Controller
public class MemberController {
	
	@Autowired
	private MemberDao memberDao;
	
	@RequestMapping("/registermember")
	public String registerMember() {
		return "user/register_member";
	}
	@RequestMapping("/registermemberconfirm")
	public String registerMemberConfirm(MemberVo memberVo) {
		memberDao.insertMember(memberVo);
		return "redirect:/loginmember";
	}
	
	@RequestMapping("/modifymember")
	public String modifyMember(@RequestParam("m_no") int m_no, Model model) {
		model.addAttribute("member", memberDao.getDetailMember(m_no));
		return "user/modify_member";
	}

	@RequestMapping("modifymemberconfirm")
	public String modifyMemberConfirm(MemberVo memberVo) {
		if (memberVo.getM_pw() == null || memberVo.getM_pw().isEmpty()) {
			MemberVo oldMember = memberDao.getDetailMember(memberVo.getM_no());
			memberVo.setM_pw(oldMember.getM_pw());
		}
		memberDao.updateMember(memberVo);
		return "redirect:/booklist";
	}
	
	@RequestMapping("/checkid")
	@ResponseBody
	public String checkId(@RequestParam("m_id") String m_id) {
		return String.valueOf(memberDao.countById(m_id));
	}
	
	@RequestMapping("loginmember")
	public String loginMember() {
		return "user/login_member";
	}
	
	@RequestMapping("/loginmemberconfirm")
	public String loginMemberConfirm(@RequestParam("m_id") String m_id, @RequestParam("m_pw") String m_pw, HttpSession session) {
		MemberVo member = memberDao.getMemberById(m_id);
		if (member != null && member.getM_pw().equals(m_pw)) {
			session.setAttribute("loginMember", member);
			return "redirect:/booklist";
		}
		return "redirect:/loginmember";
	}
	
	@RequestMapping("/logoutmember")
	public String logoutMember(HttpSession session) {
		session.invalidate();
		return "redirect:/booklist";
	}
	
}
