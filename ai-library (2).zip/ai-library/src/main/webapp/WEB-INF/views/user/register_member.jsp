<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ include file="../include/header.jsp" %>
	
	<div class="row justify-content-center">
		<div class="col-md-6">
			<div class="card p-4">
				<h4 class="mb-4 fw-bold text-center">회원가입</h4>
				<form method="post" action="registermemberconfirm">
					<div class="row mb-3">
						<label class="col-sm-3 col-form-label">아이디</label>
						<div class="col-sm-9 d-flex gap-2">
							<input type="text" name="m_id" id="m_id" class="form-control">
							<button type="button" id="checkIdBtn" class="btn btn-warning text-white flex-shrink-0">중복확인</button>
						</div>
					</div>
					
					
					<div class="row mb-3">
						<label class="col-sm-3 col-form-label">비밀번호</label>
						<div class="col-sm-9">
							<input type="text" name="m_pw" class="form-control">
						</div>
					</div>
					
					<div class="row mb-3">
						<label class="col-sm-3 col-form-label">이름</label>
						<div class="col-sm-9">
							<input type="text" name="m_name" class="form-control">
						</div>
					</div>
					
					<div class="row mb-3">
						<label class="col-sm-3 col-form-label">성별</label>
						<div class="col-sm-9 d-flex align-items-center">
							<div class="from-check form-check-inline">
								<input type="radio" name="m_gender" value="M" id="genderM"
								class="from-check-input" checked>
								<label for="genderM" class="form-check-label">남</label>
							</div>
							<div class="from-check form-check-inline">
								<input type="radio" name="m_gender" value="F" id="genderF"
								class="from-check-input">
								<label for="genderF" class="form-check-label">여</label>
							</div>
						</div>
					</div>
					
					<div class="row mb-3">
						<label class="col-sm-3 col-form-label">이메일</label>
						<div class="col-sm-9">
							<input type="text" name="m_mail" class="form-control">
						</div>
					</div>
					
					<div class="row mb-3">
						<label class="col-sm-3 col-form-label">전화</label>
						<div class="col-sm-9">
							<input type="text" name="m_phone" class="form-control">
						</div>
					</div>
					
					<div class="text-center mt-3">
						<button type="submit" class="btn btn-info px-4 me-2">가입하기</button>
						<a href="#" class="btn btn-light border px-4">취소</a>
					</div>
				</form>
				
				<script>
					let idChecked = false;
					
					document.getElementById("checkIdBtn").addEventListener("click", function () {
						const m_id = document.getElementById("m_id").value.trim();
						if (m_id === "") {
							alert("아이디를 입력하세요.");
							return;
						}
						
						fetch("checkid?m_id=" + m_id)
						.then(res => res.text())
						.then(count => {
							if (count == 0) {
								alert("사용 가능한 아이디입니다.");
								idChecked = true;
							} else {
								alert("이미 사용 중인 아이디입니다.");
								idChecked = false;
							}
						});
					});
					
					document.getElementById("m_id").addEventListener("input", function () {
						idChecked = false;
					});
					
					document.querySelector("form").addEventListener("submit", function (e) {
						if(!idChecked) {
							e.preventDefault();
							alert("아이디 중복 확인을 해주세요.");
						}
					});
				</script>
			</div>
		</div>
	</div>	

<%@ include file="../include/footer.jsp" %>